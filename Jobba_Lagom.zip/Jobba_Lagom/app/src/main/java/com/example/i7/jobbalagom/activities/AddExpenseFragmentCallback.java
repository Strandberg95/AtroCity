package com.example.i7.jobbalagom.activities;

/**
 * Created by Kajsa on 2016-04-27.
 */

public interface AddExpenseFragmentCallback {
    public void addExpense(String title, String amount, String date);
}
