package com.example.i7.jobbalagom.activities;

/**
 * Created by Jakup on 2016-04-27.
 */
public interface SetupFragmentCallback {
    public void setupUser(String name, String area, String freeSum, String title, String hWage, String cb);
}
