package com.example.i7.jobbalagom.activities.WorkRegister;

/**
 * Created by Strandberg95 on 2016-04-19.
 */
public interface DateRegisterCallback {
    public void UpdateRegisteredDate(int year, int month, int day);
}
