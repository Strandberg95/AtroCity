package com.example.i7.jobbalagom.activities.WorkRegister;

/**
 * Created by Strandberg95 on 2016-04-18.
 */
import android.view.View;

public interface MainTimeRegisterCallback {

    public void buttonPressed(View view);
}
