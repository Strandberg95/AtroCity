package com.example.i7.jobbalagom.activities.WorkRegister;

/**
 * Created by Strandberg95 on 2016-04-25.
 */
public interface TimePickerCallback {

    public void updateTime(String time);

}
