package com.example.i7.jobbalagom.local;

/**
 * Created by Anton Gustafsson on 2016-04-21.
 * Should make the actual calculation
 */
public class Calculator {
    private float tax;



    public void setTax(float tax){
        this.tax=tax;
    }
}
